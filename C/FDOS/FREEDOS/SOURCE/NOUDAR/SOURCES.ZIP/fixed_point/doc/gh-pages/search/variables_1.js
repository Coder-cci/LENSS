var searchData=
[
  ['exponent',['exponent',['../classsg14_1_1fixed__point.html#aac3836ae1f50c76a9b67e6ab9d744241',1,'sg14::fixed_point']]]
];
