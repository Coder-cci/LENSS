var searchData=
[
  ['const_5finteger',['const_integer',['../classsg14_1_1const__integer.html',1,'sg14']]]
];
