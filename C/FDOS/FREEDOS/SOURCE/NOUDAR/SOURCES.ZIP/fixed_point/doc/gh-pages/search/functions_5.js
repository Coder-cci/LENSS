var searchData=
[
  ['negate',['negate',['../namespacesg14.html#a03fe4ee59d6bb3e36129865fe6eb7a51',1,'sg14']]]
];
