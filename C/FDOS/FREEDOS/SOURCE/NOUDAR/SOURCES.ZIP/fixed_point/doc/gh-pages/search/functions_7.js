var searchData=
[
  ['sqrt',['sqrt',['../namespacesg14.html#a3fc51de1b01d64d8d204ba880709fa20',1,'sg14']]],
  ['subtract',['subtract',['../namespacesg14.html#a7bae8f58036fa48f123833e7333fa6f3',1,'sg14']]]
];
