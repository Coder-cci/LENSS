var searchData=
[
  ['literals',['literals',['../namespacesg14_1_1literals.html',1,'sg14']]],
  ['sg14',['sg14',['../namespacesg14.html',1,'']]]
];
