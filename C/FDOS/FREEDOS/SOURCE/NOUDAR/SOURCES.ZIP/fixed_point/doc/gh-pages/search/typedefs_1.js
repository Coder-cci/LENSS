var searchData=
[
  ['make_5ffixed',['make_fixed',['../namespacesg14.html#a9410b627237c65c553151fcd6ef86412',1,'sg14']]],
  ['make_5fufixed',['make_ufixed',['../namespacesg14.html#a713b7142bf0335253f18cef66752ac39',1,'sg14']]]
];
