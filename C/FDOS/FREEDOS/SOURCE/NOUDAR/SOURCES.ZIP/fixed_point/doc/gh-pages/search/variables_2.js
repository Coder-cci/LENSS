var searchData=
[
  ['fractional_5fdigits',['fractional_digits',['../classsg14_1_1fixed__point.html#a44b9739d22998ab59005e417de4b68a7',1,'sg14::fixed_point']]]
];
