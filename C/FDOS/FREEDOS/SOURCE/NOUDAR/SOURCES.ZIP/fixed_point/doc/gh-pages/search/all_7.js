var searchData=
[
  ['narrowest',['narrowest',['../classsg14_1_1elastic__integer.html#a145d1547a162b4886240f5a2cd4ae0fe',1,'sg14::elastic_integer']]],
  ['negate',['negate',['../namespacesg14.html#a03fe4ee59d6bb3e36129865fe6eb7a51',1,'sg14']]]
];
