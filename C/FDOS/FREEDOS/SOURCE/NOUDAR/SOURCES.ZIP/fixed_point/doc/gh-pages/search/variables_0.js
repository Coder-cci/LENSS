var searchData=
[
  ['digits',['digits',['../classsg14_1_1elastic__integer.html#aa68cc9b7ac0af53873b14850e92c50f6',1,'sg14::elastic_integer::digits()'],['../classsg14_1_1fixed__point.html#a79af51829ef07804fd752068f43ef68b',1,'sg14::fixed_point::digits()']]]
];
