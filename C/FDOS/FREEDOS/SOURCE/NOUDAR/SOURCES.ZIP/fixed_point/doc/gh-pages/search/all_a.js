var searchData=
[
  ['literals',['literals',['../namespacesg14_1_1literals.html',1,'sg14']]],
  ['sg14',['sg14',['../namespacesg14.html',1,'']]],
  ['sqrt',['sqrt',['../namespacesg14.html#a3fc51de1b01d64d8d204ba880709fa20',1,'sg14']]],
  ['subtract',['subtract',['../namespacesg14.html#a7bae8f58036fa48f123833e7333fa6f3',1,'sg14']]]
];
