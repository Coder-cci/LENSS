var searchData=
[
  ['rep',['rep',['../classsg14_1_1elastic__integer.html#afbd7cdaedaf6e6184f585c559f349bcf',1,'sg14::elastic_integer::rep()'],['../classsg14_1_1fixed__point.html#a664a5e95783dee0becf9d9470e513e8c',1,'sg14::fixed_point::rep()']]]
];
