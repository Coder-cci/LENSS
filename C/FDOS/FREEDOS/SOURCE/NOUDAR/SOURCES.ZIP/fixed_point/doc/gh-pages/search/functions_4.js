var searchData=
[
  ['make_5felastic_5ffixed_5fpoint',['make_elastic_fixed_point',['../namespacesg14.html#a9248d0878b8d2227c7aa0e69382453c2',1,'sg14::make_elastic_fixed_point(const_integer&lt; Integral, Value &gt;=const_integer&lt; Integral, Value &gt;{})'],['../namespacesg14.html#a93e82fab42c3f54dfc09682f15d6528a',1,'sg14::make_elastic_fixed_point(Integral value)']]],
  ['multiply',['multiply',['../namespacesg14.html#a992fbf622288c31c5e449351f988b0e8',1,'sg14']]]
];
