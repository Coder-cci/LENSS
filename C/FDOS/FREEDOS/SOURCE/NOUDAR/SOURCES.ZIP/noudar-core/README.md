# Dungeons of Noudar - core
This is the roguelike core for Dungeons of Noudar. It also contains the unit tests to ensure gameplay is as intended.

It depends on ncurses-dev (Ubuntu) and clang3.8 (uses gcc for code coverage report generation)


*update*
Dungeons of Noudar (text version) got a mention on PC Gamer, regarding it's entry on a game competition (placed 4th place):
www.pcgamer.com/silly-knight-is-one-of-6-brand-new-dos-games-you-can-play-today

![ ](/screenshot.png?raw=true)

On MS-DOS (that's right!), all it depends on is CWSDPMI.exe

![ ](/screenshot-dos.png?raw=true)
