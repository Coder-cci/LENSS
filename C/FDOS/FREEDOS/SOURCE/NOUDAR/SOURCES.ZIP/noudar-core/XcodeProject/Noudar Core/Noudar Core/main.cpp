//
//  main.cpp
//  Noudar Core
//
//  Created by Daniel Monteiro on 16/11/16.
//  Copyright © 2016 Daniel Monteiro. All rights reserved.
//

#include <iostream>

int main(int argc, const char * argv[]) {
    // insert code here...
    std::cout << "Hello, World!\n";
    return 0;
}
