Statue
======

Statue of an angel broken in half, around the hip area. A red gem is protunding
from the middle of it, but not quite revealed.

It requires charged crossbow shot to reveal the gem - and summoning the 
[master demon](master-demon.md) in the process.