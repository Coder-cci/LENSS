Locations
=========

The [Citadel](citadel.md) is composed of the following locations:

- [Church](church.md)

- [Monastery](monastery.md)

- [Cemetery](cemetery.md)

- [Patium](patium.md)

- [Prison](prison.md)

- [Mausoleum](mausoleum.md)

- [The Nest](nest.md)

- [Guard Tower](tower.md)

- [Bell Tower](bell-tower.md)
