Patium
======

The entrance to the [citadel](citadel.md), with a small square
and a broken statue. One side has the [tower](tower.md) that 
overlooks the whole place, which also guards the 
[cemetery](cemetery.md), the other has the entrance to the 
[church](church.md) and then citadel walls.

The cemetery lies on a higher ground than the 
[patium](patium.md). Nothing much going on here - it's 
kind of a training ground for the game.

Inside the [statue](statue.md), there is a small red gem 
with a interesting sparkle to it. Later in the game, the 
player will have to break the statue to start the final 
battle, in effect, summoning the 
[master demon](master-demon.md).
