Cathedral
======

A quite imponent cathedral. It is comprised of two main 
chambers and two auxiliary chambers on the first floor and 
two smaller chambers on the second floor. 

Chambers:

- The north chamber in the second floor 

Leads to the [bell tower](bell-tower.md), the resting place
for the mighty warrior, containing the [shield](shield.md).

- The north chamber in the first floor 

Is the altar, which recharges the shield of restoration.
 
- The south chamber 

The first you seen as you enter, also has the 
[vitrals](vitrals.md) on the walls on the sides. It is 
comprised of many benches for sitting and praying, with a 
red carpet running thru the middle of it.

- The east chamber on 1st floor 

Serves as the end for both stairwells for the 2nd floor 
north and south chambers.

- The west on the 1st floor

There is a door that Takes you to
[monastery](monastery.md).

- The south chamber on the 2nd floor

Has a passage from [pagan temple](prison.md), with 
exactly one clear shot path to some ropes that hold the 
cloth covering the vitrals and revealing the path to the
bell tower.

On the porches around the tower entrance, you get the only
clear shots into the ropes that hold the other vitrals covered
and that holds the tower entrance closed.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       