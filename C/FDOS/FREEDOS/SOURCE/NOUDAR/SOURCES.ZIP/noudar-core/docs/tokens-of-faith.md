Tokens of faith
===============

Little tokens used by the [monks](monks.md) to restore the 
faith of those who work on the [citadel](citadel.md) and 
purify the crops. Will usually boost the faith in 5 points 
per token. It can only be used once.

It's a small pendant with the engraving of the angel from the
[statue](statue.md) on the [patium](patium.md).

This [item](items.md) can be dropped but since it's quite
lightweight, there is no point in doing so. The player will
usually carry one or two at a time.