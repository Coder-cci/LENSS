Monks
=====

Monks that kept the citadel and renewed the faith of the 
[soldiers](fallen-heroes.md) tasked with dealing with 
possessed people all the time. There are around 20 monks on 
the [citadel](citadel.md).

Once they're defeated, they drop a 
[token of faith](tokens-of-faith.md) to replenish the 
player's faith.

They will not attack until being approached from very close.
Their attack are only punches, so not all that strong after all.