Shield of Restoration
=====================

The shield will actually not improve the player defense, since
it's too cumbersome to actually use in combat. It's not big or
heavy in any way. When charged, besides the bonus for the
[crossbow](crossbow.md), it may also, at the cost of 1 energy
point, restore 1 point of faith to the player.

To charge it, the player must bring it into the altar of the 
[church](church.md) - it will do so by 1 energy point per turn.

This [item](items.md) can be found on the 
[bell tower](bell-tower.md) and once taken, can't be dropped.

