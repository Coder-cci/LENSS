Sword
=====

The most basic weapon for the game. Deals only basic damage
(5 points).

This weapon can't hurt the [evil spirits](evil-spirit.md) nor
the [maste demon](master-demon.md). On the other hand, it's the
only weapon capable of  damaging the [warthog](warthog.md).

This [item](items.md) already starts with you and can't be 
dropped.

