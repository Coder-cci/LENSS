Prison
======

A place where the seed bearers are kept their whole life,
in a futile attempt to prevent them to become the next 
demon master.

This place is *huge*! It contains the mausoleum on one
corner and the demon nest on the other. It's actually
split in two, with a small chasm dividing it up and 
locked gates, forcing you to shoot across the gap and
and go back up to the [monastery](monastery.md) to reach for
the other side.

From the first entrance, you reach the prison itself,
with all the cell closed. To open those, you must cut 
the rope on the guards room. From there, there is a small
secret passage from one of the cell into another hallway
that's, in theory, partially inacessible. You have, still
enough access to find the [mausoleum](mausoleum.md) and the 
[crossbow](crossbow.md).
 
Once you have it, you're finally able to shoot the previously
mentioned magic seal.

On the other side, there is a pagan temple and inside it, 
the [nest](nest.md).