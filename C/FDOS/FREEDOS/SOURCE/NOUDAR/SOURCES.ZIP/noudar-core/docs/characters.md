Characters
==========

The Hero:

Not much is known. He's a former priest-turned-knight 
that got injured and is incapable of properly fighting. 
Still, he's capable of defending himself if needed.

Monsters:

- [Insane monks](monks.md)

The monks that didn't commit suicide became insane from 
the overwhelming power growing inside the cocoon. They 
will attack, despite not being capable of doing much 
damage. They will not hunt the hero.

- [Fallen warriors](fallen-heroes.md)

Once heroes, now seduced by evil, those warriors might 
provide some more challenge. They do believe to be doing 
the right thing, entranced in eternal madness. Will 
actively hunt the player.

- [Demon-Warthog](warthog.md)

A antropomorphic warthog, usually armed with maces and 
whips. They're strong, but somewhat slow and clumsly. 
Still the thick skin provides for a very long battle.

- [Evil spirits](evil-spirit.md)

Powerful entities which can drain the player's faith. 
Can only be killed with the crossbow.

- [Master Demon](master-demon.md)

Every generation, a new soul is born with the seed of 
evil. If a minor demon finds it, he will awake this seed
of evil and it will grow until becoming the focal point 
of all sins.