Master demon
============

The master demon has three forms:

- Cocoon

It's actually only a shell housing the weakened demon.
Will rupture with a single blow of a sword or a bolt
from the [crossbow](crossbow.md), immediately releasing
the demon in it's weakened form.

It looks like a slime ball, full of blisters and pulsing
on every turn.

- Weakened

While the looks is mostly of a nude woman with very long
ginger hair (a lot like the _birth of aphrodite_ painting)
and an angelic face, her power is something to be reckoned
with. He's invulnerable to any of your attacks, with the
crossbow merely stunning her.

Her attacks are mostly energy melee attacks with long nails
and will usually cause her to gradually get weak until she
appears defeated and simply vanishes with a gush of wind.

- Strong

Later on, with her return, she's a lot stronger, with her
melee attacks not only causing more damage, but also 
capable of summoning more [evil spirits](evil-spirit.md)
on her aid.

Her looks changed slightly, not including small horns
on her forehead.