The nest
========

The cave containing the [cocoon](master-demon.md), that
was once a pagan section of the [dungeon](prison.md).

Also next to it, you see woman's clothes on the floor
and blood trails on the floor, next to the clothes.

On other end of the nest, you see a small altar with 
animal bones and old blood stains, along with pillars 
with runic symbols engraved onto it.

The walls have torn pieces of cloth containing images in
patterns of the sun, the moon, triangles, stars, branches
of wheat and a lynx.

There are sections of the walls made entirely of human
skulls, with horned wooden masks hanging from it.

To exit the nest, you must shoot the cocoon and wake up
the demon. The exit back to the [monastery](monastery.md)
closes behind you as you enter.

After the battle, you end up at the [church](church.md)
back again.

