Evil spirit
===========

Evil spirits are the acolytes of the 
[master demon's](master-demon.md) maturing process. 
The spectra of it's old worshippers, being kept in a 
eternal state of existence, but always suffering.

They're not strong but can only be harmed with the 
[crossbow](crossbow.md).

Their appearance is that of a faded image, partially
translucent, with ragged robes and with a faint green
glow inside it.