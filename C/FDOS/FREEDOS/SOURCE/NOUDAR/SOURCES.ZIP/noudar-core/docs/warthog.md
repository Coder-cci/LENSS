Warthog
=======

A very strong and aggressive demon, with a taste for human
flesh. It's also quite resistant, being only harmed (and
only a little) by the sword.

It can be found on the cemetery, guarding the entrance to the
tower.
Being a guardian, it won't pursue the player from very far
(but that can be attributed to it's poor eye sight as well).

It's mostly naked, but with it's lower torso being covered
on scales, but otherwise looking like that of a normal man.

It's weapon of choice is a hammer to smash bones.
