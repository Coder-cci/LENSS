Cemetery
========

A small cemetery containing the remains of the less 
important serfs and priests from the [citadel](citadel.md).

Inside it is the [tower](tower.md) overlooking the whole
[citadel](citadel.md).

Here, all sorts of evil spirits will attack the player.
The best option is to run inside the tower and go for
[pagan temple](prison.md).

Here, the  player will also face the [Warthog](warthog.md)
that's guarding the tower.