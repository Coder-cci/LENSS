Bell tower
==========

Contains the remains of the penultimate guardian. On top of it's tomb is is the 
[shield of restoration](shield.md), which he forged himself (being a alchemist).

It's part of the [church](church.md), accessible thru the stairwell on the north
chamber, on the 2nd floor.

It's actually a quite small chamber, decorated with other tombs and bones from
other past guardians. It's actually the base of the tower and not the tower 
itself. There is, even, a small escalator to the top of the tower.