Tower
=====

The guard tower sits on the center of the [citadel](citadel.md),
overlooking it from all flanks. Given the importance of
the [dungeon](prison.md) it gives access for, it's very 
important to have it well guarded.

The only way to have way inside it is to use the break a
magic seal that holds the door shut. The best way to do
it is thru the window that faces the cemetery. To align
this shot, there is a small porch from a big burial vault.

That shot will have to pass thru the windows of another
vault containing demons locked up.

Once inside the tower, all the player has to do is go down
the stairs and into the [pagan temple](prison.md).