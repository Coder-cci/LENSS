Monastery
=========

The day-to-day place for the clergy which keeps the 
church going and perform the lithurgy.

It' composed of a kitchen, a lavatory, the dorms, a 
kitchen, a storage room, the studies room and hall that
begins at the entrance and goes all the way to the 
[dungeon](prison.md) entrance, with a exit to the 
backyard, which leads to [cemetery](cemetery.md) and 
[mausoleum](mausoleum.md).

You first visit the dungeon first by rupturing the 
ropes inside the small altars, located on the dorms, 
storage and study area.

When you reemerge from the dungeon, the Dungeon 
entrance is closed but the exit to the backyard is 
open.

After that, the player won't visit the monastery again 
(but it's chimney is visible from most surface levels).

