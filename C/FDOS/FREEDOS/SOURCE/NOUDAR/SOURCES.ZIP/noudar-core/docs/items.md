Items
=====

Weapons:

- [Sword](sword.md)

An old sword, but capable of providing basic defense without
requiring any cooling time.

- [Crossbow](crossbow.md)

A skull from the previous incarnation of the 
[master demon](master-demon.md). 
The last bearer of the god's will to defeat it threw his 
own life into the battle, thus forever blessing the pieces 
from her weapon. This skull is mounted on a piece of wood, 
effectively making a "energy crossbow".

- [Tokens of faith](tokens-of-faith.md)

Small tokens used by the monks during the last season to 
bless their crops, this tokens also help the hero keep it's
faith in balance.

- [Shield of restoration](shield.md)

The shield of restoration was forged by a valiant Alchemist 
that helped defeating the demon on this grounds, 2 centuries
earlier. It is capable of channeling the surrounding goodness
into energy for it's bearer. If used with the crossbow, it 
becomes very powerful and makes it also very strong. Also 
capable of healing it's bearer from time to time.