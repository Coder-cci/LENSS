Mausoleum
=========

Holds the sacred relics that helped defeat the demons 
over the centuries. Fate creates the situations that 
point out the current instrument of god. This time, 
it's the [crossbow](crossbow.md) necessary to open the 
gates on the other side of the [dungeon](prison.md). 
All other relics will be unavailable.

It's a chamber with a small altar and some candles 
burning.

Important to note that the shield will be indicated to be
kept there, but it's going to be missing. A candle and a
cross in blood will help guiding the players into looking
over the [cathedral](church.md) to find the 
[bell tower](bell-tower.md).
