Crossbow
========

Requires 3 points of energy, dealing the base damage + 1 
(thus, 6 damage points) on a simple shot.

When charged with the [shield of restoration](shield.md), 
it will perform a second 16 damage points attack.

When fired, will have a laborious reloading process, thus
taking 2 turns to cooldown. Will recharge at all times.

It's the only weapon capable of hurting 
[evil spirits](evil-spirit.md) and the 
[master demon](master-demon.md). On the other hand, can't
make a scratch into the [warthog demon](warthog.md).

This [item](items.md) is being kept on the 
[dungeon](prison.md) and once taken, can't be dropped.