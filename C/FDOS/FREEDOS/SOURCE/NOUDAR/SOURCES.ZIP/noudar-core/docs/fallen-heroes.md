Fallen heroes
=============

Soldiers originally tasked with securing the 
[dungeon](prison.md), but that since then, have gone mad.

They're armed with swords and light armor. Being soldiers,
some more agressivity has to be expected.

Their attacks are stronger, but they're vulnerable to
all kinds of weapons. After being defeated, they will drop
nothing.