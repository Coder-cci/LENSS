Citadel
=======

Is the main setting of the game. It's a small citadel built
on top of a flat top steep hill. It has only one small 
entrance at end of a narrowing path from the main land, 
leading into the [patium](patium.md).

It is guarded by a huge [tower](tower.md) on it's center,
with another, smaller, housing the church 
[bell](bell-tower.md).

One has to think of it as a religious-military fortification,
with the bare minimal for withstanding any outside attack
and the best provisions to perform it's intented purpuse:
keep the demons out of our plane of existance.

It's mostly run by [monks](monks.md) and a rotation of
detachements of [soldiers](fallen-heroes.md), housed in
the [dungeon](prison.md).