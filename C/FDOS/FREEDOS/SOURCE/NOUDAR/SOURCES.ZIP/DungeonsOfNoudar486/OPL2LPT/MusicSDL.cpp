#include <algorithm>
#include <array>
#include <random>
#include <time.h>
#include <unistd.h>
#include <memory>
#include <fstream>
#include <sstream>
#include <unordered_map>

using std::vector;

#include "IFileLoaderDelegate.h"
#include "CPackedFileReader.h"

#include <string>
#include <vector>

void playMusic(const std::string &music) {
}

void setupOPL2(int port) {
}

void stopSounds() {
}

void playTune(const std::string &music) {

}

void soundTick() {

}

void muteSound() {

}