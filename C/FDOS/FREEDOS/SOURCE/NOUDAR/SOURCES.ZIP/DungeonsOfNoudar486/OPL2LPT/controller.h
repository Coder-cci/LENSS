#ifndef DEMOTUNE_H_
#define DEMOTUNE_H_
extern void music_set(const char* melody1, const char* melody2, const char* melody3);
extern void music_setup();
extern void music_loop();
extern void music_shutdown();
#endif
