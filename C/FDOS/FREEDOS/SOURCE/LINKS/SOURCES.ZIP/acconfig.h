
@BOTTOM@

/* */
#undef VERSION

/* */
#undef HAVE_OPENMP

/* */
#undef HAVE_LONG_LONG

/* */
#undef HAVE_POINTER_COMPARISON_BUG

/* */
#undef HAVE_MAXINT_CONVERSION_BUG

/* */
#undef HAVE_STDLIB_H_X

/* */
#undef HAVE_SOCKLEN_T

/* */
#undef HAVE_VOLATILE

/* */
#undef HAVE_RESTRICT

/* */
#undef HAVE___RESTRICT

/* */
#undef HAVE_ERRNO

/* */
#undef C_BIG_ENDIAN

/* */
#undef C_LITTLE_ENDIAN

/* */
#undef RENAME_OVER_EXISTING_FILES

/* */
#undef HAVE_STRLEN

/* */
#undef HAVE_STRNLEN

/* */
#undef HAVE_STRCPY

/* */
#undef HAVE_STRNCPY

/* */
#undef HAVE_STRCHR

/* */
#undef HAVE_STRRCHR

/* */
#undef HAVE_STRCMP

/* */
#undef HAVE_STRNCMP

/* */
#undef HAVE_STRCSPN

/* */
#undef HAVE_STRSPN

/* */
#undef HAVE_STRSTR

/* */
#undef HAVE_MEMCMP

/* */
#undef HAVE_MEMCHR

/* */
#undef HAVE_MEMRCHR

/* */
#undef HAVE_MEMCPY

/* */
#undef HAVE_MEMMOVE

/* */
#undef HAVE_MEMSET

/* */
#undef HAVE_MEMMEM

/* */
#undef HAVE_STRERROR

/* */
#undef HAVE_SIGFILLSET

/* */
#undef HAVE_SIGSETJMP

/* */
#undef HAVE_GCC_ASSEMBLER

/* */
#undef HAVE___BUILTIN_ADD_OVERFLOW

/* */
#undef HAVE___BUILTIN_CLZ

/* */
#undef DEBUGLEVEL

/* */
#undef HAVE_CLOCK_GETTIME

/* */
#undef HAVE_GETHOSTBYNAME

/* */
#undef HAVE_GETHOSTBYNAME_BUG

/* */
#undef SUPPORT_IPV6

/* */
#undef SUPPORT_IPV6_SCOPE

/* */
#undef HAVE_POW

/* */
#undef HAVE_POWF

/* */
#undef JS

/* */
#undef CHCEME_FLEXI_LIBU

/* */
#undef HAVE_PCRE

/* */
#undef HAVE_REGEX

/* */
#undef ENABLE_UTF8

/* */
#undef HAVE_BEGINTHREAD

/* */
#undef HAVE_PTHREADS

/* */
#undef X2

/* */
#undef HAVE_XSETLOCALE

/* */
#undef HAVE_SSL

/* */
#undef HAVE_OPENSSL

/* */
#undef HAVE_NSS

/* */
#undef HAVE_CRYPTO_SET_MEM_FUNCTIONS_1

/* */
#undef HAVE_CRYPTO_SET_MEM_FUNCTIONS_2

/* */
#undef HAVE_ZLIB

/* */
#undef HAVE_BROTLI

/* */
#undef HAVE_ZSTD

/* */
#undef HAVE_BZIP2

/* */
#undef HAVE_LZMA

/* */
#undef HAVE_LZIP

/* */
#undef G

/* */
#undef GRDRV_SVGALIB

/* */
#undef GRDRV_FB

/* */
#undef GRDRV_DIRECTFB

/* */
#undef GRDRV_X

/* */
#undef GRDRV_SDL

/* */
#undef GRDRV_PMSHELL

/* */
#undef GRDRV_ATHEOS

/* */
#undef GRDRV_HAIKU

/* */
#undef GRDRV_GRX

/* Have freetype */
#undef HAVE_FREETYPE

/* Jpeg by Clock */
#undef HAVE_JPEG

/* Tiff by Brain */
#undef HAVE_TIFF

/* SVG */
#undef HAVE_SVG

/* WebP */
#undef HAVE_WEBP

/* AVIF */
#undef HAVE_AVIF

/* Gpm_Event has wdx and wdy */
#undef HAVE_WDX_WDY
