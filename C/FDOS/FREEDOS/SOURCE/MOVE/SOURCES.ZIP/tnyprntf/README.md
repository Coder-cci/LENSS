Abbreviated printf Functions
----------------------------

From DOS-C

Copyright (c) 1995 Pasquale J. Villani.

All Rights Reserved.
