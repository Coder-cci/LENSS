#ifndef __MOVEDIR__H__
#define __MOVEDIR__H__

extern int MoveDirectory(const char* src_filename, const char* dest_filename);
extern int RenameTree(const char* src_filename, const char* dest_filename);

#endif
