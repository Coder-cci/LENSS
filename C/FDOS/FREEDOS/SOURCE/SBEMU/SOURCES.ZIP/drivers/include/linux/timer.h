#ifndef SBEMU_LINUX_TIMER_H
#define SBEMU_LINUX_TIMER_H

struct timer {
  int tim;
};

struct timer_list {
  int tim;
};

#endif
