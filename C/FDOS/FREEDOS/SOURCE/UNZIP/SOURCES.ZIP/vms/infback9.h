/* 2008-07-29 SMS.
 * VMS-specific INFBACK9.H jacket header file to help find the
 * relatively obscure actual header file.
 *
 * The logical name INCL_ZLIB_CONTRIB_INFBACK9 must point to the ZLIB
 * source subdirectory where infback9.h is situated.
 */

#include "INCL_ZLIB_CONTRIB_INFBACK9:INFBACK9.H"
