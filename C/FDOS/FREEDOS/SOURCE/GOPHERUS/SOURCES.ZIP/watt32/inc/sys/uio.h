/*!\file sys/uio.h
 * Dummy header.
 */

#ifndef __SYS_UIO_H
#define __SYS_UIO_H

/* This dummy header is required while building e.g. tcpdump
 */

#endif
