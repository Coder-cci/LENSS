#ifndef __PREFSGUI_H__
#define __PREFSGUI_H__

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


void a_Prefsgui_show();


#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif /* __PREFSGUI_H__ */
