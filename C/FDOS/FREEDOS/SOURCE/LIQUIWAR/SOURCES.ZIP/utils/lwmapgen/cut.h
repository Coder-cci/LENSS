/*
* Copyright (C) 2003, David Redick
* Released under the GNU General Public License (v2)
*/

#ifndef LWMAPGEN_CUT_H
#define LWMAPGEN_CUT_H

void cut();

#endif
