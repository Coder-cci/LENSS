FDNET uses DHCP.EXE.

The sources for DHCP.EXE are available in the FreeDOS mTCP package.

Sources for DHCP.EXE may also be found at the developers website.

http://www.brutman.com/mTCP/
