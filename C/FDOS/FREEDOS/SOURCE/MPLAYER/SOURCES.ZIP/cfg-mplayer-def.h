static char* default_config=
"# Write your default config options here!\n"
"\n"
//"nosound=nem"
"\n";

