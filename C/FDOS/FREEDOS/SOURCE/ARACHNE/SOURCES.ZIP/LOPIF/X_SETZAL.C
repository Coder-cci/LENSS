//--------- Nastaveni param. pro zalamovani textu -----------
#include "x_lopif.h"

void x_set_zalom(int istyle, int ostyle, float MaxMez, float MaxRozt)
{
//     xg_istyle = istyle;
//     xg_ostyle = ostyle;
//     xg_MaxMez = MaxMez;
//     xg_MaxRozt= MaxRozt;
}