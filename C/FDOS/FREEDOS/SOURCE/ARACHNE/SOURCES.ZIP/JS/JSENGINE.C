
//========================================================================
//JavaScript for Arachne by xChaos & Homeless
//========================================================================

int js_method()   //asi
{

 // bla bla bal bla

 function=js_getfunction("document","href");

 function(thisobject,argument);

 // bla bla bal bla

 function=js_getfunction("navigator","status");

 function(thisobject,argument);


}
