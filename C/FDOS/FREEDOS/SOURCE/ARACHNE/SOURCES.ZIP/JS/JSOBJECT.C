
//========================================================================
// JavaScript for Arachne by xChaos & Homeless
//========================================================================

#include "arachne.h
#include "javascr.h

// napr. getfunction("document","href");

// js_method(....)

