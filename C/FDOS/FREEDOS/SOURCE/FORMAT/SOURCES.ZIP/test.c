#include <stdlib.h>
#include <stdio.h>
#include "kitten.h"

 nl_catd catalog;

void main(int argc, char *argv[])
{
  catalog = catopen(argv[0], 0); /* init support for translated messages */
  printf(catgets(catalog, 0, 1, "Failed to print msg 0.1\n"));
  catclose(catalog);
}

