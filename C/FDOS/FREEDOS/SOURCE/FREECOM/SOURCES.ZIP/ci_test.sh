#!/bin/sh

echo No tests created yet!
exit 0
