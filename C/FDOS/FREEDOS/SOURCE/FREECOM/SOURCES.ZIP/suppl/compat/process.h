/* process.h compatibility header */

#ifndef __PROCESS_H
#define __PROCESS_H

#include <stdlib.h>

#endif
