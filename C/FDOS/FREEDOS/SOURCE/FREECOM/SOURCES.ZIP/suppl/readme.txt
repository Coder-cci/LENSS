This version of FreeCOM has been compiled and linked with the SUPPL
library, which is available from the Steffen's site at

ftp://ftp-fd.inf.fh-rhein-sieg.de/pub/freedos/local/ALPHA
-or-
http://www2.inf.fh-rhein-sieg.de/~skaise2a/ska/sources.html#suppl

A stripped down variant of SUPPL has been included into the FreeCOM
release, because of several complains about the wicked process of
compilation. You can bypass the FreeCOM-build.bat sense of SUPPL
by creating a file called "SKIP" in this directory (<<FreeCOM-Root>>\SUPPL).
That way, you can use your own SUPPL, e.g. a newer release of it.
