/* $Id$
 *  REM -- includes comments "remarks" into batch scripts
 */

#include "../config.h"

#include "../include/command.h"

int cmd_rem (char * param) { (void)param; return 0; }
