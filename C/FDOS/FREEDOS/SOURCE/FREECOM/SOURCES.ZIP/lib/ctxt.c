/* $Id$

	Dynamic context of the FreeCOM instance
*/

#include "../config.h"

#include "../include/context.h"

ctxt_t ctxt = 0;
