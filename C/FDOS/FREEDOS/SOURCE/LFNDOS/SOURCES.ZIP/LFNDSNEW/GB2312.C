/*

  GB2312 Code Table Generator
  Written by Jiang Hong.

*/

#include <stdio.h>
#include <stdlib.h>

void main()
{
	int i,j;
	FILE *fp;

	printf( "GB2312 Codetable Generator by Jiang Hong.\n" );
	fp=fopen( "GB2312.TXT","wb+" );
	for( i=160;i<255;i++ )
	for( j=161;j<255;j++ ) {
		fwrite( &i,1,1,fp );
		fwrite( &j,1,1,fp );
	}
	fclose( fp );
	printf( "GB2312.TXT generated.\n" );
}
