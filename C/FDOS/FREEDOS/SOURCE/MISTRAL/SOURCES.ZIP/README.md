# The Mistral Report - invisible affairs

Prebuilt binaries:
https://montyontherun.itch.io/the-mistral-report