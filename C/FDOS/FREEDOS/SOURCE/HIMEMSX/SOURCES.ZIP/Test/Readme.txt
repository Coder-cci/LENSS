
  CopyFile is a simple utility to test the speed of file copies.
  It displays the times required to read and write the file, in ms resolution.
