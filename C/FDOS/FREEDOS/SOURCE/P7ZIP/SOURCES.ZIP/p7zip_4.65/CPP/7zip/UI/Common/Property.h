// Property.h

#ifndef __PROPERTY_H
#define __PROPERTY_H

#include "Common/MyString.h"

struct CProperty
{
  UString Name;
  UString Value;
};

#endif
