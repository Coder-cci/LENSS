// Archive/BZip2Item.h

#ifndef __ARCHIVE_BZIP2_ITEM_H
#define __ARCHIVE_BZIP2_ITEM_H

namespace NArchive {
namespace NBZip2 {
  
struct CItem
{
  UInt64 PackSize;
  UInt64 UnPackSize;
};

}}

#endif



