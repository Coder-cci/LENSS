// DefaultName.h

#ifndef __DEFAULTNAME_H
#define __DEFAULTNAME_H

#include "Common/MyString.h"

UString GetDefaultName2(const UString &fileName,
    const UString &extension, const UString &addSubExtension);

#endif
