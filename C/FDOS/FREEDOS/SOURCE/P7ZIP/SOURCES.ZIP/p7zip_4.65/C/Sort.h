/* Sort.h -- Sort functions
2008-03-19
Igor Pavlov
Public domain */

#ifndef __7Z_SORT_H
#define __7Z_SORT_H

#include "Types.h"

void HeapSort(UInt32 *p, UInt32 size);
/* void HeapSortRef(UInt32 *p, UInt32 *vals, UInt32 size); */

#endif
