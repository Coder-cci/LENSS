/* All dirent.h features that libmspack uses are provided by the watcom
 * direct.h, so just shim it for DOS builds. */
# include <direct.h>
