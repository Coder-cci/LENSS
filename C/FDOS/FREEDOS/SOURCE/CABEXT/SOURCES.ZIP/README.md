# cabextract
`cabextract` is Free Software for extracting **Microsoft cabinet files**, also called `.CAB` files. It is distributed under the GNU GPL license and is based on the portable LGPL `libmspack` library. 

`cabextract` is released at https://www.cabextract.org.uk/

# libmspack
`libmspack` is a library for some loosely related Microsoft compression formats: CAB, CHM, HLP, LIT, KWAJ and SZDD.

`libmspack` is released at https://www.cabextract.org.uk/libmspack/

