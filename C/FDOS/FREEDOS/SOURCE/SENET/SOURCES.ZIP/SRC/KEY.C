/* test program */

#include <stdio.h>
#include <conio.h>

int
main()
{
    int key;

    puts("test program to check for keys");

    puts("press any key ... Q to quit");

    do {
	key = getch();
	if (key == 0) {
	    /* extended key .. read getch again to get the ext key code */
	    key = getch();
	    printf("EXTENDED KEY: <%c> (%d)\n", key, key);
	}
	else {
	    printf("KEY: <%c> (%d)\n", key, key);
	}
    } while (key != 'Q');

    puts("done");
    return 0;
}
