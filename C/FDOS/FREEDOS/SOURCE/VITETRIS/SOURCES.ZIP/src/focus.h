extern int in_xterm;

void in_xterm_init();
int xterm_hasfocus();
