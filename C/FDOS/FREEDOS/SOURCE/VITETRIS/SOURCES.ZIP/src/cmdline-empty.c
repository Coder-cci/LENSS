void proc_args(char **args, int n) {}
