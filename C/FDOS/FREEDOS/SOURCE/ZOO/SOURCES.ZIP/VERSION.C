/* derived from: version.c 2.9 1988/08/25 12:43:57  */
char version[] =
"zoo 2.1 $Date: 91/07/09 02:10:34 $";
