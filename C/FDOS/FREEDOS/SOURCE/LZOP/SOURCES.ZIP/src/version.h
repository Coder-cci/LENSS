#define LZOP_VERSION            0x1040
#define LZOP_VERSION_STRING     "1.04"
#define LZOP_VERSION_DATE       "Aug 10th 2017"

/* vim:set ts=4 sw=4 et: */
