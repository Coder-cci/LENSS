#ifndef _VERSION_H
#define _VERSION_H

/* SSHDOS version */

#define SSH_VERSION	"0.95"

#endif
