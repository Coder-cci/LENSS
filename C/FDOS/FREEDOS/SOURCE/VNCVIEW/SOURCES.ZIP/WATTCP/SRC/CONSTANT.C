#include <wattcp.h>

void main( void )
{
    printf("tcp_Socket %u\n\r", sizeof(tcp_Socket));
    printf("udp_Socket %u\n\r", sizeof(udp_Socket));
}
